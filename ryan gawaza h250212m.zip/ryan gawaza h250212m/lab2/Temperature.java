package lab2;
public class Temperature {
    private final double kelvin;

    // private constructor
    private Temperature(double kelvin) {
        if (kelvin < 0) throw new IllegalArgumentException("Below absolute zero");
        this.kelvin = kelvin;
    }

    // static factories are clearer than constructors
    public static Temperature fromCelsius(double c) {
        return new Temperature(c + 273.15);
    }

    public static Temperature fromFahrenheit(double f) {
        return new Temperature((f - 32) * 5/9 + 273.15);
    }

    public static Temperature fromKelvin(double k) {
        return new Temperature(k);
    }

    public double getCelsius() { return kelvin - 273.15; }
    public double getFahrenheit() { return (kelvin - 273.15) * 9/5 + 32; }
    public double getKelvin() { return kelvin; }

    @Override public String toString() {
        return String.format("%.2f K / %.2f C / %.2f F", kelvin, getCelsius(), getFahrenheit());
    }

    public static void main(String[] args) {
        Temperature t1 = Temperature.fromCelsius(25);
        Temperature t2 = Temperature.fromFahrenheit(77);
        Temperature t3 = Temperature.fromKelvin(300);
        System.out.println(t1);
        System.out.println(t2);
        System.out.println(t3);
    }
}