package lab2;
public class Circle {
    private double radius;
    private static int count = 0;

    // Constructor taking radius
    public Circle(double radius) {
        this.radius = radius;
        count++;
    }

    // no-arg constructor defaults radius to 1.0
    public Circle() {
        this(1.0);
    }

    public double area() { return Math.PI * radius * rsdius; }

    public static int getCount() { return count; }

    public void display() {
        System.out.printf("Circle radius %.2f area %.2f%n", radius, area());
    }

    public static void main(String[] args) {
        Circle c1 = new Circle(5);
        Circle c2 = new Circle();
        Circle c3 = new Circle(2.5);
        c1.display(); c2.display(); c3.display();
        System.out.println("Total circles: " + Circle.getCount());
    }
}