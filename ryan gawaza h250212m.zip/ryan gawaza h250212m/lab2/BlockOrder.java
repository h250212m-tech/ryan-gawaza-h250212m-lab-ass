package lab2;
public class BlockOrder {
    static { System.out.println("static block 1"); }
    static int x = print("static field 1");

    { System.out.println("instance block 1"); }
    int y = print("instance field 1");
    { System.out.println("instance block 2"); }

    static { System.out.println("static block 2"); }

    BlockOrder() { System.out.println("constructor"); }

    static int print(String s) { System.out.println(s); return 1; }

    public static void main(String[] args) {
        System.out.println("--- main start ---");
        new BlockOrder();
        System.out.println("--- second object ---");
        new BlockOrder();
    }
}

