package lab6;
abstract class ShapeAbs {
    protected String color;
    ShapeAbs(String color){this.color=color;}
    abstract double area();
    abstract double perimeter();
    void display(){System.out.printf("%s area %.2f perimeter %.2f%n", color, area(), perimeter());}
}
class CircleAbs extends ShapeAbs {
    double r; CircleAbs(String color, double r){super(color); this.r=r;}
    @Override double area(){return Math.PI*r*r;}
    @Override double perimeter(){return 2*Math.PI*r;}
}
class RectangleAbs extends ShapeAbs {
    double w,h; RectangleAbs(String c,double w,double h){super(c); this.w=w; this.h=h;}
    @Override double area(){return w*h;}
    @Override double perimeter(){return 2*(w+h);}
}
public class ShapeAbstract {
    public static void main(String[] args) {
        ShapeAbs[] arr = { new CircleAbs("Red",5), new RectangleAbs("Blue",4,6) };
        for(ShapeAbs s: arr) s.display();
        // ShapeAbs s = new ShapeAbs(); // ERROR - abstract
    }
}
