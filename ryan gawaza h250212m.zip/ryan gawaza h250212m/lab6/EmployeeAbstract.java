package lab6;
abstract class EmployeeAbs {
    String name; EmployeeAbs(String name){this.name=name;}
    abstract double calculatePay();
    void describe(){System.out.printf("%s pay %.2f%n", name, calculatePay());}
}
class FullTime extends EmployeeAbs {
    double salary; FullTime(String n,double s){super(n); salary=s;}
    @Override double calculatePay(){return salary;}
}
class PartTime extends EmployeeAbs {
    double rate; int hours; PartTime(String n,double r,int h){super(n); rate=r; hours=h;}
    @Override double calculatePay(){return rate*hours;}
}
public class EmployeeAbstract {
    public static void main(String[] args) {
        EmployeeAbs[] staff = { new FullTime("Kuda",5000), new PartTime("Ryan",25,80) };
        for(EmployeeAbs e: staff) e.describe();
    }
}