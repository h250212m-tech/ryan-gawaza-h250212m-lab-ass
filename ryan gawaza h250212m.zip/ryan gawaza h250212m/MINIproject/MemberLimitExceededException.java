package MINIproject;
public class MemberLimitExceededException extends Exception {
    public MemberLimitExceededException(String msg) {
        super(msg);
    }
}