package MINIproject;
public class Book extends libraryItem implements Borrowable {
    private final String author;
    public Book(String id, String title, String author) { super(id, title); this.author = author; }
    public Book(String id, String title, String author, boolean available) { super(id, title); this.author = author; setAvailable(available); }
    @Override public int loanPeriodDays() { return 14; }
    @Override public void borrow(Member member) throws ItemNotAvailableException, MemberLimitExceededException {
        if(!isAvailable()) throw new ItemNotAvailableException(getTitle() + " is not available");
        if(member.getLoanCount() >= 3) throw new MemberLimitExceededException(member.getName() + " has reached 3 loans limit");
        setAvailable(false);
    }
    @Override public void giveBack() { setAvailable(true); }
    @Override String toCsv() { return super.toCsv() + "," + author; }
}