package MINIproject;
public class Dvd extends libraryItem implements Borrowable {
    private final String director;
    public Dvd(String id, String title, String director) { super(id, title); this.director = director; }
    public Dvd(String id, String title, String director, boolean available) { super(id, title); this.director = director; setAvailable(available); }
    @Override public int loanPeriodDays() { return 7; }
    @Override public void borrow(Member member) throws ItemNotAvailableException, MemberLimitExceededException {
        if(!isAvailable()) throw new ItemNotAvailableException(getTitle() + " is not available");
        if(member.getLoanCount() >= 3) throw new MemberLimitExceededException(member.getName() + " limit exceeded");
        setAvailable(false);
    }
    @Override public void giveBack() { setAvailable(true); }
    @Override String toCsv() { return super.toCsv() + "," + director; }
}