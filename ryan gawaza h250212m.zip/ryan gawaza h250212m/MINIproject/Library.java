package MINIproject;
import java.io.IOException;
import java.nio.file.*;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

public class Library {
    private final Map<String, libraryItem> items = new HashMap<>();
    private final Map<String, Member> members = new HashMap<>();
    private final List<Loan> loans = new ArrayList<>();

    // ---- Operations ----
    public void addItem(libraryItem item) { items.put(item.getId(), item); }
    public void registerMember(Member m) { members.put(m.getId(), m); }

    public void borrow(String memberId, String itemId) throws ItemNotAvailableException, MemberLimitExceededException {
        Member m = members.get(memberId);
        libraryItem item = items.get(itemId);
        if(m==null) throw new IllegalArgumentException("Member not found: "+memberId);
        if(item==null) throw new IllegalArgumentException("Item not found: "+itemId);

        Borrowable b = (Borrowable) item;
        b.borrow(m); // may throw custom exceptions

        m.addLoan(itemId);
        loans.add(new Loan(memberId, itemId, LocalDate.now(), item.loanPeriodDays()));
        System.out.println("Borrowed: "+item.getTitle()+" to "+m.getName()+" due in "+item.loanPeriodDays()+" days");
    }

    public void returnItem(String memberId, String itemId) {
        Member m = members.get(memberId);
        libraryItem item = items.get(itemId);
        if(m!=null && item!=null) {
            ((Borrowable)item).giveBack();
            m.removeLoan(itemId);
            loans.removeIf(l -> l.getMemberId().equals(memberId) && l.getItemId().equals(itemId));
            System.out.println("Returned: "+item.getTitle());
        }
    }

    // Stream API - search by title
    public List<libraryItem> searchByTitle(String text) {
        return items.values().stream()
           .filter(i -> i.getTitle().toLowerCase().contains(text.toLowerCase()))
           .sorted(Comparator.comparing(libraryItem::getTitle))
           .toList();
    }

    public List<Loan> overdueLoans() {
        return loans.stream().filter(Loan::isOverdue).toList();
    }

    public void listAllItems() { items.values().forEach(System.out::println); }
    public void listAllMembers() { members.values().forEach(System.out::println); }

    // ---- Persistence CSV ----
    public void save() throws IOException {
        Files.write(Path.of("items.csv"), items.values().stream().map(libraryItem::toCsv).toList());
        Files.write(Path.of("members.csv"), members.values().stream().map(Member::toCsv).toList());
        System.out.println("Saved items.csv and members.csv");
    }

    public void load() throws IOException {
        if(Files.exists(Path.of("items.csv"))) {
            for(String line : Files.readAllLines(Path.of("items.csv"))) {
                String[] p = line.split(",");
                // id,title,available,type,author/director
                String id=p[0], title=p[1]; boolean avail=Boolean.parseBoolean(p[2]); String type=p[3]; String extra=p.length>4?p[4]:"";
                if(type.equals("Book")) addItem(new Book(id,title,extra,avail));
                else addItem(new Dvd(id,title,extra,avail));
            }
        }
        if(Files.exists(Path.of("members.csv"))) {
            for(String line : Files.readAllLines(Path.of("members.csv"))) {
                Member m = Member.fromCsv(line); registerMember(m);
            }
        }
    }
}