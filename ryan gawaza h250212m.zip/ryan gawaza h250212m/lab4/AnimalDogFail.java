package lab4;
class Animal {
    String name;
    Animal(String name) { this.name = name; } // NO no-arg constructor
}
// class Dog extends Animal { } // COMPILE ERROR: Dog needs to call super(name)
// Fix:
class DogFix extends Animal {
    DogFix(String name) { super(name); }
}
public class AnimalDogFail {
    public static void main(String[] args) {
        DogFix d = new DogFix("Buddy");
        System.out.println("Fixed: " + d.name);
    }
}