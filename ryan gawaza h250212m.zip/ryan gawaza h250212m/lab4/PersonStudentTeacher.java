package lab4;
class Person {
    String name; int age;
    Person(String name, int age) { this.name = name; this.age = age; }
    void display() { System.out.println("Name: " + name + ", Age: " + age); }
}
class Student extends Person {
    String course;
    Student(String name, int age, String course) { super(name, age); this.course = course; }
    @Override void display() { super.display(); System.out.println("Course: " + course); }
}
class Teacher extends Person {
    String subject;
    Teacher(String name, int age, String subject) { super(name, age); this.subject = subject; }
    @Override void display() { super.display(); System.out.println("Subject: " + subject); }
}
public class PersonStudentTeacher {
    public static void main(String[] args) {
        Person p = new Person("Tariro", 30); p.display();
        Student s = new Student("Ryan", 21, "OOP"); s.display();
        Teacher t = new Teacher("Mr Moyo", 45, "Java"); t.display();
    }
}