package lab8;
import java.util.*;
public class Basic_RemoveDuplicates {
    public static void main(String[] args) {
        List<String> names = new ArrayList<>(List.of("Tariro","Farai","Tariro","Kuda","Farai"));
        System.out.println("With duplicates: " + names);
        Set<String> unique = new LinkedHashSet<>(names); // keeps insertion order
        List<String> deduped = new ArrayList<>(unique);
        System.out.println("Without duplicates: " + deduped);
    }
}
