package lab8;
import java.util.*;
public class Basic_ArrayList10 {
    public static void main(String[] args) {
        List<Integer> nums = new ArrayList<>(List.of(5,12,3,88,23,44,9,15,67,2));
        int sum = 0; int max = nums.get(0);
        for (int n : nums) { sum += n; if (n > max) max = n; }
        System.out.println("List: " + nums);
        System.out.println("Sum: " + sum + " Max: " + max);
        Collections.reverse(nums);
        System.out.println("Reversed: " + nums);
    }
}