package lab1;
public class Car {

    String brand;
    int year;
    double mileage;

    void display() {
        System.out.println("Brand: " + brand);
        System.out.println("Year: " + year);
        System.out.println("Mileage: " + mileage + " km");
        System.out.println("-------------------");
    }
    boolean isAntique(){
    int currentyear = 2026;
    return(currentyear - year ) > 25;
    }
    public static void main(String[] args) {

        Car car1 = new Car();
        car1.brand = "Toyota";
        car1.year = 2018;
        car1.mileage = 45000;

        Car car2 = new Car();
        car2.brand = "Honda";
        car2.year = 2020;
        car2.mileage = 30000;

        Car car3 = new Car();
        car3.brand = "BMW";
        car3.year = 2015;
        car3.mileage = 65000;

        car1.display();
        car2.display();
        car3.display();
        System.out.println(car1.brand + "antique? " + car1.isAntique());
        System.out.println(car3.brand + "amtique" + car3.isAntique());


    }
}