package lab1;
public class Rectangle {
    double width;
    double height;

    Rectangle(double width, double height) {
        this.width = width;
        this.height = height;
    }

    double area() {
        return width * height;
    }

    double perimeter() {
        return 2 * (width + height);
    }

    public static void main(String[] args) {
        Rectangle[] arr = new Rectangle[5];
        arr[0] = new Rectangle(2, 3);
        arr[1] = new Rectangle(5, 5);
        arr[2] = new Rectangle(4, 10);
        arr[3] = new Rectangle(3, 7);
        arr[4] = new Rectangle(6, 2);

        Rectangle biggest = arr[0];
        for (Rectangle r : arr) {
            if (r.area() > biggest.area()) {
                biggest = r;
            }
        }
        System.out.println("Largest rectangle area: " + biggest.area());
        System.out.println("Width: " + biggest.width + " Height: " + biggest.height);

        // Reference test
        Rectangle r1 = new Rectangle(2, 3);
        Rectangle r2 = r1;
        r2.width = 100;
        System.out.println("After r2.width=100, r1.width = " + r1.width + " (same object!)");
    }
}