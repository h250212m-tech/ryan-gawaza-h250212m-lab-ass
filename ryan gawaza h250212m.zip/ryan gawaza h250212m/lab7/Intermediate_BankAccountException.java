package lab7;
class InsufficientFundsException2 extends Exception {
    InsufficientFundsException2(String msg) { super(msg); }
}

class BankAccountEx {
    private double balance;
    BankAccountEx(double opening) { this.balance = opening; }
    // OLD: returned false -> caller could ignore error
    // NEW: throws checked exception -> forces caller to handle
    void withdraw(double amount) throws InsufficientFundsException2 {
        if (amount > balance) {
            throw new InsufficientFundsException2("Balance " + balance + " insufficient for " + amount);
        }
        balance -= amount;
        System.out.println("Withdrew " + amount + " remaining " + balance);
    }
    double getBalance() { return balance; }
}

public class Intermediate_BankAccountException {
    public static void main(String[] args) {
        BankAccountEx acc = new BankAccountEx(500);
        try {
            acc.withdraw(100);
            acc.withdraw(1000); // will throw
        } catch (InsufficientFundsException2 e) {
            System.out.println("Trade-off: Exception forces handling, unlike boolean return that can be ignored. Caught: " + e.getMessage());
        }
    }
}