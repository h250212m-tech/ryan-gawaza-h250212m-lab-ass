package lab7;
public class Basic_ArrayAccess {
    static void accessArray(int[] arr, int index) {
        try {
            System.out.println("Element at " + index + " = " + arr[index]);
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Caught ArrayIndexOutOfBounds: " + e.getMessage());
        }
    }
    public static void main(String[] args) {
        int[] data = {10,20,30};
        accessArray(data, 1);
        accessArray(data, 5);
    }
}