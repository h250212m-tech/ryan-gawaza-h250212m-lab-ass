package lab5;
public class PrinterOverload {
    void print(int x){System.out.println("int: " + x);}
    void print(double x){System.out.println("double: " + x);}
    void print(String x){System.out.println("String: " + x);}
    void print(int[] arr){System.out.print("int[]: "); for(int i: arr) System.out.print(i+" "); System.out.println();}
    public static void main(String[] args) {
        PrinterOverload p = new PrinterOverload();
        p.print(5); p.print(3.14); p.print("Hello"); p.print(new int[]{1,2,3});
    }
}