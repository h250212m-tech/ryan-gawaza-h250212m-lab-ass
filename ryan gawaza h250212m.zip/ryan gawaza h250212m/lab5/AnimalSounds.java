package lab5;
class Animal2 { void sound(){System.out.println("Some sound");} }
class Cat extends Animal2 { @Override void sound(){System.out.println("Meow");} }
class Cow extends Animal2 { @Override void sound(){System.out.println("Moo");} }
class Duck extends Animal2 { @Override void sound(){System.out.println("Quack");} }
public class AnimalSounds {
    public static void main(String[] args) {
        Animal2[] animals = { new Cat(), new Cow(), new Duck(), new Cat() };
        for (Animal2 a : animals) a.sound();
    }
}