package lab9;
import java.util.*;
class Book {
    private final String isbn; private final String title;
    Book(String isbn, String title) { this.isbn = isbn; this.title = title; }
    @Override public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Book b)) return false;
        return isbn.equals(b.isbn); // equality by ISBN only
    }
    @Override public int hashCode() { return isbn.hashCode(); }
    @Override public String toString() { return isbn + " - " + title; }
}
public class Intermediate_BookEquals {
    public static void main(String[] args) {
        Set<Book> set = new HashSet<>();
        set.add(new Book("978-0134685991", "Effective Java"));
        set.add(new Book("978-0134685991", "Effective Java Duplicate")); // same ISBN
        set.add(new Book("978-0596009205", "Head First Java"));
        System.out.println("Set size (should be 2, duplicate rejected): " + set.size());
        System.out.println(set);
    }
}