package lab9;
enum Level { LOW, MEDIUM, HIGH }

public class Basic_LevelEnum {
    static void advice(Level l) {
        switch (l) {
            case LOW -> System.out.println("LOW: Take it easy");
            case MEDIUM -> System.out.println("MEDIUM: Stay focused");
            case HIGH -> System.out.println("HIGH: Urgent action needed!");
        }
    }
    public static void main(String[] args) {
        for (Level lv : Level.values()) {
            System.out.print(lv + " ordinal " + lv.ordinal() + " -> ");
            advice(lv);
        }
    }
}