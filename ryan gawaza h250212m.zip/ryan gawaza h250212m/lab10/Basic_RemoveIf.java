package lab10;
import java.util.*;
import java.util.function.Predicate;
public class Basic_RemoveIf {
    public static void main(String[] args) {
        List<Integer> nums = new ArrayList<>(List.of(1,2,3,4,5,6,7,8));
        Predicate<Integer> isEven = n -> n % 2 == 0;
        nums.removeIf(isEven); // uses Predicate
        System.out.println("Odd only: " + nums);
    }
}