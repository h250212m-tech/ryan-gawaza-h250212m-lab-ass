package lab3;
import java.util.*;

public class BankAccountHistory {
    private final String accountNumber;
    private String ownerName;
    private double balance;
    private final List<String> history = new ArrayList<>();

    public BankAccountHistory(String accNo, String owner, double opening) {
        this.accountNumber = accNo; this.ownerName = owner; this.balance = opening;
        history.add("Opened with " + opening);
    }

    public void deposit(double amount) {
        if (amount <= 0) throw new IllegalArgumentException("Deposit must be positive");
        balance += amount;
        history.add("Deposit: +" + amount + " -> " + balance);
    }

    public boolean withdraw(double amount) {
        if (amount > balance) { history.add("Failed withdraw: " + amount); return false; }
        balance -= amount;
        history.add("Withdraw: -" + amount + " -> " + balance);
        return true;
    }

    public List<String> getHistory() {
        return Collections.unmodifiableList(history); // safe getter
    }

    public static void main(String[] args) {
        BankAccountHistory acc = new BankAccountHistory("ACC-002", "Ryan", 1000);
        acc.deposit(200); acc.withdraw(500); acc.withdraw(5000);
        System.out.println(acc.getHistory());
        // acc.getHistory().clear(); // blocked - unmodifiable
    }
}