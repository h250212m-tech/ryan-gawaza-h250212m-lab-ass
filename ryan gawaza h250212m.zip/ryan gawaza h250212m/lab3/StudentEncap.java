package lab3;
public class StudentEncap {
    private String name;
    private int marks; // 0 to 100

    public StudentEncap(String name, int marks) {
        setName(name);
        setMarks(marks);
    }

    public String getName() { return name; }
    public void setName(String name) {
        if (name == null || name.isBlank()) throw new IllegalArgumentException("Name required");
        this.name = name.trim();
    }

    public int getMarks() { return marks; }
    public void setMarks(int marks) {
        if (marks < 0 || marks > 100) throw new IllegalArgumentException("Marks must be 0-100");
        this.marks = marks;
    }

    // No field for grade - calculated
    public String getGrade() {
        if (marks >= 80) return "A";
        if (marks >= 60) return "B";
        if (marks >= 40) return "C";
        return "F";
    }

    @Override public String toString() { return name + " marks: " + marks + " grade: " + getGrade(); }

    public static void main(String[] args) {
        StudentEncap s1 = new StudentEncap("Kuda", 85);
        StudentEncap s2 = new StudentEncap("Tino", 55);
        System.out.println(s1);
        System.out.println(s2);
        try { s1.setMarks(150); } catch (IllegalArgumentException e) {
            System.out.println("Rejected: " + e.getMessage());
        }
    }
}